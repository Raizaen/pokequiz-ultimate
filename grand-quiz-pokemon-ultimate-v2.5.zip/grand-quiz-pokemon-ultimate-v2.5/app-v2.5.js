const rounds = [
  { title:"Le Laboratoire", rules:"Retrouve le Pokémon avec des indices progressifs. Les points diminuent à chaque indice.", questions:[
    {difficulty:1, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["Je suis un Pokémon de la première génération.","Je suis de type Eau et Psy.","Je n’évolue pas et je n’ai pas de pré-évolution.","Mon joyau central peut briller de sept couleurs.","Mon numéro national est le 121."], a:"Staross", exp:"Staross est le Pokémon n°121, de type Eau/Psy, sans évolution connue.", source:"Pokédex officiel Pokémon et données des jeux principaux."},
    {difficulty:2, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["J’ai été introduit à Hoenn.","Ma famille compte trois stades.","Mon évolution finale est de type Acier/Psy.","J’évolue une première fois au niveau 20.","Je suis Terhal."], a:"Terhal", exp:"Terhal évolue en Métang au niveau 20, puis en Métalosse au niveau 45.", source:"Données des jeux principaux."}
  ]},
  { title:"Le Lieu Perdu", rules:"Identifie un lieu des jeux Pokémon à partir de sa description.", questions:[
    {difficulty:1, points:[10,7,4], q:"Quel est ce lieu ?", clues:["Cette ville se trouve à Johto.","Elle abrite une Arène spécialisée dans le type Acier.","Son phare est lié à un Pharamp malade."], a:"Oliville", exp:"À Oliville, Jasmine veille sur le Pharamp du phare avant d’accepter le défi d’Arène.", source:"Pokémon Or, Argent et Cristal."},
    {difficulty:3, points:[10,7,4], q:"Quel est ce lieu ?", clues:["Il se trouve dans la région d’Unys.","On y affronte le Conseil 4 après l’avoir traversé.","Il accueille la Ligue Pokémon d’Unys."], a:"La Ligue Pokémon d’Unys", exp:"La Ligue se situe au nord de la Route Victoire d’Unys.", source:"Pokémon Noir, Blanc, Noir 2 et Blanc 2."}
  ]},
  { title:"Sprite Mystère", rules:"Reconnais le Pokémon à partir d’un sprite masqué. Révèle l’indice pour éclaircir l’image.", questions:[
    {difficulty:2, points:[10,6,3], q:"À quel Pokémon appartient ce sprite ?", image:"https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/94.png", imageMode:"silhouette", clues:["Il est de type Spectre/Poison.","Il est le dernier stade d’une famille de Kanto.","Il s’agit d’Ectoplasma."], a:"Ectoplasma", exp:"Le sprite utilisé est celui d’Ectoplasma, Pokémon n°94.", source:"Sprite public du projet PokeAPI."},
    {difficulty:3, points:[10,6,3], q:"À quel Pokémon appartient ce sprite ?", image:"https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/637.png", imageMode:"pixelated", clues:["Il est de type Insecte/Feu.","Il possède six ailes.","Il s’agit de Pyrax."], a:"Pyrax", exp:"Pyrax est le Pokémon n°637, introduit en cinquième génération.", source:"Sprite public du projet PokeAPI."}
  ]},
  { title:"Pokédex Impossible", rules:"Retrouve le Pokémon associé à une description officielle ou à un fait Pokédex explicite.", questions:[
    {difficulty:2, points:10, q:"Quel Pokémon est connu pour dormir environ 18 heures par jour et ne se réveiller que pour manger ?", choices:["Parecool","Ronflex","Dodoala","Munna"], a:"Ronflex", exp:"Les entrées du Pokédex décrivent régulièrement Ronflex comme ne faisant presque que manger et dormir.", source:"Entrées Pokédex de Ronflex dans plusieurs jeux."},
    {difficulty:3, points:10, q:"Quel Pokémon transporte son crâne maternel et pleure lorsqu’il pense à sa mère ?", choices:["Osselait","Vostourno","Téraclope","Fantominus"], a:"Osselait", exp:"Cette caractéristique est au cœur des entrées Pokédex d’Osselait.", source:"Entrées Pokédex d’Osselait."}
  ]},
  { title:"Capacités & Objets", rules:"Identifie une capacité ou un objet grâce à ses propriétés en combat.", questions:[
    {difficulty:2, points:10, q:"Quelle capacité de statut de type Normal possède une priorité de +4 et protège son utilisateur de la plupart des attaques pendant le tour ?", choices:["Abri","Détection","Prévention","Garde Large"], a:"Abri", exp:"Abri possède une priorité de +4 dans les générations modernes et protège de la plupart des capacités pendant le tour.", source:"Données de capacités des jeux principaux."},
    {difficulty:3, points:10, q:"Quel objet augmente de 50 % la Vitesse de son porteur mais le bloque sur la première capacité choisie ?", choices:["Bandeau Choix","Lunettes Choix","Mouchoir Choix","Orbe Vie"], a:"Mouchoir Choix", exp:"Le Mouchoir Choix multiplie la Vitesse par 1,5 et verrouille la capacité utilisée.", source:"Données d’objets des jeux principaux."}
  ]},
  { title:"Le Stratège", rules:"Résous des situations de combat, de statistiques et d’interactions.", questions:[
    {difficulty:3, points:10, q:"Sans modification de priorité, lequel agit normalement en premier à niveau égal : un Nostenfer avec 130 de Vitesse de base ou un Alakazam avec 120 ?", choices:["Nostenfer","Alakazam","Toujours égalité","Cela dépend uniquement des PV"], a:"Nostenfer", exp:"À investissement, IV et nature identiques, la Vitesse de base supérieure de Nostenfer lui donne l’avantage.", source:"Statistiques de base et règle d’ordre des actions."},
    {difficulty:4, points:10, q:"Quelle immunité naturelle empêche une capacité de type Sol de toucher un Pokémon de type Vol, sauf effet particulier ?", choices:["Immunité de type","Résistance x4","Talent obligatoire","Objet tenu"], a:"Immunité de type", exp:"Le type Vol confère normalement une immunité aux attaques de type Sol.", source:"Table des types des jeux principaux."}
  ]},
  { title:"Anime Pokémon", rules:"Questions sur les personnages, compagnons et événements majeurs de la série animée.", questions:[
    {difficulty:1, points:10, q:"Quel Pokémon est le partenaire emblématique de Sacha depuis le début de la série ?", choices:["Évoli","Pikachu","Dracaufeu","Lucario"], a:"Pikachu", exp:"Pikachu accompagne Sacha dès le premier épisode.", source:"Série animée Pokémon."},
    {difficulty:2, points:10, q:"Quel membre de la Team Rocket voyage le plus souvent avec Jessie et James ?", choices:["Miaouss","Qulbutoké","Rattatac","Persian"], a:"Miaouss", exp:"Miaouss forme avec Jessie et James le trio récurrent de la Team Rocket.", source:"Série animée Pokémon."}
  ]},
  { title:"Spin-offs", rules:"Explore Pokémon Ranger, Donjon Mystère, Snap, GO, UNITE et les autres séries dérivées.", questions:[
    {difficulty:2, points:10, q:"Dans Pokémon Donjon Mystère, quel rôle le joueur incarne-t-il au début de nombreuses aventures ?", choices:["Un Pokémon transformé","Un Professeur","Un Champion d’Arène","Un membre de la Team Rocket"], a:"Un Pokémon transformé", exp:"Le protagoniste humain se réveille généralement sous la forme d’un Pokémon.", source:"Série Pokémon Donjon Mystère."},
    {difficulty:3, points:10, q:"Quel accessoire est emblématique des Pokémon Rangers pour capturer temporairement l’amitié d’un Pokémon ?", choices:["Capstick","Pokématos","Nav-Dex","Bracelet Z"], a:"Capstick", exp:"Le Capstick est l’outil central des Pokémon Rangers.", source:"Série Pokémon Ranger."}
  ]},
  { title:"Cartes & Culture", rules:"Mélange de JCC, histoire de la licence, formes et culture générale.", questions:[
    {difficulty:2, points:10, q:"Dans le Jeu de Cartes à Collectionner, quel symbole représente habituellement une carte rare dans les extensions classiques ?", choices:["Un cercle","Un losange","Une étoile","Un triangle"], a:"Une étoile", exp:"Le cercle indique commun, le losange peu commune et l’étoile rare dans le système classique.", source:"Règles et symboles de rareté du JCC Pokémon."},
    {difficulty:3, points:10, q:"Quel Pokémon porte le numéro 001 du Pokédex National ?", choices:["Pikachu","Bulbizarre","Mew","Rondoudou"], a:"Bulbizarre", exp:"Bulbizarre ouvre le Pokédex National au numéro 001.", source:"Pokédex National."}
  ]},
  { title:"Boss Final", rules:"Finale de niveau Maître : trois questions, points attribués individuellement.", questions:[
    {difficulty:4, points:10, q:"Quel talent double la Vitesse sous la pluie ?", choices:["Chlorophylle","Glissade","Baigne Sable","Délestage"], a:"Glissade", exp:"Glissade double la Vitesse du Pokémon lorsque la pluie est active.", source:"Données des talents des jeux principaux."},
    {difficulty:4, points:10, q:"Quel Pokémon pseudo-légendaire évolue de Diamat au niveau 64 ?", choices:["Drattak","Trioxhydre","Carchacrok","Muplodocus"], a:"Trioxhydre", exp:"Solochi évolue en Diamat au niveau 50, puis Diamat en Trioxhydre au niveau 64.", source:"Données d’évolution des jeux principaux."},
    {difficulty:5, points:10, q:"Dans les combats modernes, que copie Morphing en plus de l’apparence, des types, du talent, des statistiques et des capacités de la cible ?", choices:["Le niveau","Les PV actuels","Les changements de statistiques","L’objet tenu"], a:"Les changements de statistiques", exp:"Morphing copie notamment les modifications de statistiques de la cible, mais conserve les PV et le niveau de l’utilisateur.", source:"Mécanique de Morphing dans les jeux principaux."}
  ]}
];


// Questions supplémentaires utilisées pour renouveler chaque émission.
const extraQuestionBanks = [
  [
    {difficulty:1, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["Je suis originaire de Johto.","Je suis de type Eau.","Je possède deux évolutions.","Mon évolution finale est Aligatueur.","Je suis Kaiminus."], a:"Kaiminus", exp:"Kaiminus évolue en Crocrodil puis en Aligatueur.", source:"Données des jeux principaux."},
    {difficulty:2, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["Je suis originaire de Sinnoh.","Je suis de type Électrik.","Je n’ai pas d’évolution.","Je ressemble à un écureuil volant.","Je suis Pachirisu."], a:"Pachirisu", exp:"Pachirisu est un Pokémon Électrik sans évolution introduit à Sinnoh.", source:"Pokédex National."},
    {difficulty:1, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["Je suis originaire de Kanto.","Je suis de type Feu.","Je possède deux évolutions.","Mon évolution finale est Dracaufeu.","Je suis Salamèche."], a:"Salamèche", exp:"Salamèche évolue en Reptincel puis en Dracaufeu.", source:"Données des jeux principaux."},
    {difficulty:1, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["Je suis originaire de Hoenn.","Je suis de type Plante.","Je possède deux évolutions.","Mon évolution finale est Jungko.","Je suis Arcko."], a:"Arcko", exp:"Arcko évolue en Massko puis en Jungko.", source:"Données des jeux principaux."},
    {difficulty:2, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["Je suis originaire d’Unys.","Je suis de type Ténèbres/Dragon.","Je suis le premier stade d’une famille de trois.","J’évolue en Diamat au niveau 50.","Je suis Solochi."], a:"Solochi", exp:"Solochi évolue en Diamat au niveau 50, puis en Trioxhydre au niveau 64.", source:"Données des jeux principaux."},
    {difficulty:2, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["Je suis originaire de Kalos.","Je suis de type Acier/Spectre.","Je suis le premier stade d’une famille de trois.","Je ressemble à une épée ancienne.","Je suis Monorpale."], a:"Monorpale", accepted:["Monorpal"], exp:"Monorpale évolue en Dimoclès puis en Exagide.", source:"Données des jeux principaux."},
    {difficulty:2, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["Je suis originaire d’Alola.","Je suis de type Spectre/Plante.","Je suis un Pokémon de départ.","Mon évolution finale est Archéduc.","Je suis Brindibou."], a:"Brindibou", exp:"Brindibou évolue en Efflèche puis en Archéduc.", source:"Données des jeux principaux."},
    {difficulty:2, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["Je suis originaire de Galar.","Je suis de type Feu.","Je suis un Pokémon de départ.","Mon évolution finale est Pyrobut.","Je suis Flambino."], a:"Flambino", exp:"Flambino évolue en Lapyro puis en Pyrobut.", source:"Données des jeux principaux."},
    {difficulty:2, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["Je suis originaire de Paldea.","Je suis de type Eau.","Je suis un Pokémon de départ.","Mon évolution finale est Palmaval.","Je suis Coiffeton."], a:"Coiffeton", exp:"Coiffeton évolue en Canarbello puis en Palmaval.", source:"Données des jeux principaux."},
    {difficulty:3, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["Je suis originaire de Sinnoh.","Je suis de type Dragon/Sol.","Je suis le premier stade d’une famille de trois.","Mon évolution finale est Carchacrok.","Je suis Griknot."], a:"Griknot", exp:"Griknot évolue en Carmache puis en Carchacrok.", source:"Données des jeux principaux."},
    {difficulty:3, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["Je suis originaire de Hoenn.","Je suis de type Dragon.","Je suis le premier stade d’une famille de trois.","Mon évolution finale est Drattak.","Je suis Draby."], a:"Draby", exp:"Draby évolue en Drackhaus puis en Drattak.", source:"Données des jeux principaux."},
    {difficulty:3, points:[10,8,6,4,2], q:"Quel Pokémon suis-je ?", clues:["Je suis originaire d’Unys.","Je suis de type Feu/Insecte.","Je n’ai qu’une évolution.","Mon évolution est Pyrax.","Je suis Pyronille."], a:"Pyronille", exp:"Pyronille évolue en Pyrax au niveau 59.", source:"Données des jeux principaux."}
  ],
  [
    {difficulty:2, points:[10,7,4], q:"Quel est ce lieu ?", clues:["Cette ville se situe à Kanto.","Elle accueille une Arène de type Psy.","Morgane en est la Championne."], a:"Safrania", exp:"Safrania abrite l’Arène de Morgane et le siège de la Sylphe SARL.", source:"Jeux principaux de Kanto."},
    {difficulty:2, points:[10,7,4], q:"Quel est ce lieu ?", clues:["Cette ville se situe à Hoenn.","Elle possède une Arène de type Feu.","Adriane en est la Championne."], a:"Vermilava", exp:"Vermilava est la ville thermale de Hoenn où se trouve l’Arène d’Adriane.", source:"Pokémon Rubis, Saphir et Émeraude."}
  ],
  [
    {difficulty:2, points:[10,6,3], q:"À quel Pokémon appartient ce sprite ?", image:"https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/448.png", imageMode:"silhouette", clues:["Il est de type Combat/Acier.","Il utilise l’aura.","Il s’agit de Lucario."], a:"Lucario", exp:"Le sprite utilisé est celui de Lucario, Pokémon n°448.", source:"Sprite public du projet PokeAPI."},
    {difficulty:3, points:[10,6,3], q:"À quel Pokémon appartient ce sprite ?", image:"https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/778.png", imageMode:"pixelated", clues:["Il est de type Spectre/Fée.","Il se cache sous un déguisement.","Il s’agit de Mimiqui."], a:"Mimiqui", exp:"Le sprite utilisé est celui de Mimiqui, Pokémon n°778.", source:"Sprite public du projet PokeAPI."}
  ],
  [
    {difficulty:2, points:10, q:"Quel Pokémon est réputé porter un poireau comme arme ?", choices:["Canarticho","Psykokwak","Couaneton","Bekipan"], a:"Canarticho", exp:"Canarticho combat avec la tige végétale qu’il transporte.", source:"Entrées Pokédex de Canarticho."},
    {difficulty:3, points:10, q:"Quel Pokémon est décrit comme pouvant changer de forme selon la météo ?", choices:["Morphéo","Métamorph","Zorua","Motisma"], a:"Morphéo", exp:"Morphéo change de forme selon le climat grâce à son talent Météo.", source:"Entrées Pokédex et données de Morphéo."}
  ],
  [
    {difficulty:2, points:10, q:"Quel objet restaure progressivement les PV du porteur à chaque tour ?", choices:["Restes","Orbe Vie","Ceinture Force","Herbe Blanche"], a:"Restes", exp:"Les Restes rendent une fraction des PV du porteur à la fin de chaque tour.", source:"Données d’objets des jeux principaux."},
    {difficulty:3, points:10, q:"Quelle capacité de type Électrik peut paralyser et possède 90 de puissance dans les générations modernes ?", choices:["Tonnerre","Fatal-Foudre","Étincelle","Éclair"], a:"Tonnerre", exp:"Tonnerre possède 90 de puissance et peut paralyser la cible.", source:"Données de capacités des jeux principaux."}
  ],
  [
    {difficulty:3, points:10, q:"Quel talent empêche un Pokémon de s’endormir ?", choices:["Insomnia","Cran","Attention","Tempo Perso"], a:"Insomnia", exp:"Insomnia empêche le Pokémon de s’endormir.", source:"Données des talents des jeux principaux."},
    {difficulty:4, points:10, q:"Quelle nature augmente la Vitesse et diminue l’Attaque ?", choices:["Timide","Jovial","Modeste","Assuré"], a:"Timide", exp:"La nature Timide augmente la Vitesse et réduit l’Attaque.", source:"Table des natures des jeux principaux."}
  ],
  [
    {difficulty:1, points:10, q:"Quel Pokémon de Sacha refuse d’abord d’évoluer grâce à une Pierre Foudre ?", choices:["Pikachu","Carapuce","Bulbizarre","Héricendre"], a:"Pikachu", exp:"Pikachu refuse la Pierre Foudre et choisit de rester sous sa forme actuelle.", source:"Série animée Pokémon."},
    {difficulty:2, points:10, q:"Quelle compagne de Sacha souhaite devenir Coordinatrice Pokémon à Hoenn ?", choices:["Flora","Ondine","Aurore","Iris"], a:"Flora", exp:"Flora découvre les Concours Pokémon et poursuit une carrière de Coordinatrice.", source:"Série animée Pokémon Advanced."}
  ],
  [
    {difficulty:2, points:10, q:"Dans Pokémon Snap, quel est l’objectif principal du joueur ?", choices:["Photographier des Pokémon","Capturer des Pokémon","Battre des Arènes","Élever des œufs"], a:"Photographier des Pokémon", exp:"La série Pokémon Snap repose sur l’observation et la photographie des Pokémon.", source:"Série Pokémon Snap."},
    {difficulty:3, points:10, q:"Dans Pokémon UNITE, combien de joueurs composent normalement chaque équipe dans les matchs standards ?", choices:["3","4","5","6"], a:"5", exp:"Les matchs standards de Pokémon UNITE opposent deux équipes de cinq joueurs.", source:"Règles de Pokémon UNITE."}
  ],
  [
    {difficulty:2, points:10, q:"Quel duo de jeux a inauguré la région d’Unys ?", choices:["Noir et Blanc","X et Y","Soleil et Lune","Diamant et Perle"], a:"Noir et Blanc", exp:"Pokémon Noir et Pokémon Blanc ont introduit la région d’Unys.", source:"Historique des jeux principaux."},
    {difficulty:3, points:10, q:"Quel type a été introduit dans la sixième génération ?", choices:["Fée","Ténèbres","Acier","Dragon"], a:"Fée", exp:"Le type Fée a été ajouté avec Pokémon X et Y.", source:"Pokémon X et Y."}
  ],
  [
    {difficulty:4, points:10, q:"Quel talent augmente l’Attaque après avoir mis K.O. un adversaire ?", choices:["Impudence","Intimidation","Acharné","Colérique"], a:"Impudence", exp:"Impudence augmente l’Attaque du Pokémon lorsqu’il met un adversaire K.O.", source:"Données des talents des jeux principaux."},
    {difficulty:4, points:10, q:"Quel Pokémon possède la statistique de base en PV la plus élevée parmi ces choix ?", choices:["Leuphorie","Ronflex","Wailord","Regigigas"], a:"Leuphorie", exp:"Leuphorie possède 255 points de base en PV.", source:"Statistiques de base des jeux principaux."},
    {difficulty:5, points:10, q:"Quelle capacité retire les entry hazards du côté du lanceur tout en attaquant ?", choices:["Tour Rapide","Anti-Brume","Demi-Tour","Change Éclair"], a:"Tour Rapide", accepted:["Tour Rapide"], exp:"Tour Rapide inflige des dégâts et retire notamment Piège de Roc, Picots et Pics Toxik du côté de l’utilisateur.", source:"Mécanique de Tour Rapide dans les jeux principaux."}
  ]
];

rounds.forEach((round, index) => {
  round.questions = round.questions.concat(extraQuestionBanks[index] || []);
  round.questions.forEach((question, qIndex) => {
    question.id = `${index}-${qIndex}-${normalizeId(question.a)}-${normalizeId(question.q).slice(0,24)}`;
  });
});

function normalizeId(value){return String(value||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")}
function shuffled(arr){const copy=[...arr];for(let i=copy.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[copy[i],copy[j]]=[copy[j],copy[i]]}return copy}
function buildGameRounds(){
  const queueKey="gqpu-question-queues-v23";
  const savedQueues=JSON.parse(localStorage.getItem(queueKey)||"{}");
  const nextQueues={};

  const selected=rounds.map((round,index)=>{
    const count=Math.min(index===rounds.length-1?3:2,round.questions.length);
    const validIds=new Set(round.questions.map(question=>question.id));
    let queue=(savedQueues[index]||[]).filter(id=>validIds.has(id));

    // Une manche fonctionne comme un paquet de cartes : chaque question est
    // tirée une seule fois avant que le paquet entier soit remélangé.
    const queued=new Set(queue);
    const missing=round.questions.map(question=>question.id).filter(id=>!queued.has(id));
    if(missing.length) queue.push(...shuffled(missing));

    // Si le paquet est épuisé, on crée un nouveau cycle. On évite de placer
    // immédiatement en tête les questions qui viennent juste d’être jouées.
    if(queue.length<count){
      const lastPlayed=JSON.parse(localStorage.getItem("gqpu-last-played-v23")||"{}")[index]||[];
      const lastSet=new Set(lastPlayed);
      const freshCycle=shuffled(round.questions.map(question=>question.id));
      freshCycle.sort((a,b)=>Number(lastSet.has(a))-Number(lastSet.has(b)));
      queue.push(...freshCycle);
    }

    const pickedIds=queue.splice(0,count);
    nextQueues[index]=queue;
    const byId=new Map(round.questions.map(question=>[question.id,question]));
    return {...round,questions:pickedIds.map(id=>byId.get(id)).filter(Boolean)};
  });

  localStorage.setItem(queueKey,JSON.stringify(nextQueues));
  localStorage.setItem("gqpu-last-played-v23",JSON.stringify(Object.fromEntries(
    selected.map((round,index)=>[index,round.questions.map(question=>question.id)])
  )));
  return selected;
}

const $=s=>document.querySelector(s); const state={players:[],round:0,question:0,revealed:false,clues:0,timer:null,timeLeft:30,responses:{},choiceOrders:{},activeRounds:[],settings:{timer:30,shuffle:true,sound:true}};
const screens={setup:$("#setupScreen"),game:$("#gameScreen"),final:$("#finalScreen")};
function showScreen(name){Object.values(screens).forEach(x=>x.classList.remove("active"));screens[name].classList.add("active")}
function addPlayerInput(value=""){const wrap=document.createElement("div");wrap.className="player-row";wrap.innerHTML=`<input maxlength="20" placeholder="Nom du Dresseur" value="${value}"><button class="ghost remove-player">✕</button>`;wrap.querySelector(".remove-player").onclick=()=>{if($("#playerInputs").children.length>1)wrap.remove()};$("#playerInputs").append(wrap)}
addPlayerInput("Dresseur 1");addPlayerInput("Dresseur 2");
$("#addPlayerBtn").onclick=()=>{if($("#playerInputs").children.length<8)addPlayerInput(`Dresseur ${$("#playerInputs").children.length+1}`)};
function beep(freq=520,dur=.08){if(!state.settings.sound)return;try{const ctx=new AudioContext();const o=ctx.createOscillator(),g=ctx.createGain();o.frequency.value=freq;o.connect(g);g.connect(ctx.destination);g.gain.setValueAtTime(.08,ctx.currentTime);g.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+dur);o.start();o.stop(ctx.currentTime+dur)}catch{}}
function shuffle(arr){return [...arr].sort(()=>Math.random()-.5)}
function startGame(){const names=[...document.querySelectorAll("#playerInputs input")].map(i=>i.value.trim()).filter(Boolean);state.players=(names.length?names:["Dresseur"]).map(name=>({name,score:0}));state.settings.timer=Number($("#timerSelect").value);state.settings.shuffle=$("#shuffleToggle").checked;state.settings.sound=$("#soundToggle").checked;state.round=0;state.question=0;state.responses={};state.choiceOrders={};state.activeRounds=buildGameRounds();save();showScreen("game");renderRoundList();renderQuestion();}
$("#startBtn").onclick=startGame;
function current(){return state.activeRounds[state.round].questions[state.question]}
function renderRoundList(){const el=$("#roundList");el.innerHTML="";state.activeRounds.forEach((r,i)=>{const d=document.createElement("div");d.className="round-item "+(i===state.round?"active ":"")+(i<state.round?"done":"");d.innerHTML=`<span class="round-number">${i+1}</span><span>${r.title}</span><span>${i<state.round?"✓":""}</span>`;el.append(d)});renderScores()}
function renderScores(){const sorted=[...state.players].sort((a,b)=>b.score-a.score);$("#scoreboard").innerHTML=sorted.map((p,i)=>`<div class="score-row"><span>${i+1}. ${p.name}</span><strong>${p.score} pts</strong></div>`).join("")}

function questionKey(){return `${state.round}-${state.question}`}
function normalizeAnswer(value){return String(value||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[’']/g," ").replace(/[^a-z0-9]+/g," ").trim().replace(/^(le|la|les|l|un|une)\s+/,"")}
function acceptedAnswers(q){return [q.a,...(q.accepted||[])].map(normalizeAnswer)}
function isCorrectAnswer(value,q){return acceptedAnswers(q).includes(normalizeAnswer(value))}
function responsesForQuestion(){const key=questionKey();if(!state.responses[key])state.responses[key]={};return state.responses[key]}
const MAX_ATTEMPTS=3;
function normalizeSavedResponse(saved={}){if(saved.submitted&&saved.correct===false&&saved.attempts==null)return {...saved,attempts:MAX_ATTEMPTS,locked:true};return saved}
function getChoiceOrder(q){const key=questionKey();state.choiceOrders=state.choiceOrders||{};if(!state.choiceOrders[key])state.choiceOrders[key]=state.settings.shuffle?shuffle(q.choices):[...q.choices];return state.choiceOrders[key]}
function renderResponseInputs(){const q=current(),responses=responsesForQuestion(),box=$("#playerResponses");box.innerHTML="";state.players.forEach((p,i)=>{const saved=normalizeSavedResponse(responses[i]||{});responses[i]=saved;const attempts=saved.attempts||0,locked=Boolean(saved.correct||saved.locked||attempts>=MAX_ATTEMPTS||state.revealed);const stateClass=saved.correct?"correct locked":locked&&attempts>=MAX_ATTEMPTS?"incorrect locked":"pending";const row=document.createElement("div");row.className=`response-row ${stateClass} ${q.choices?"qcm-row":"text-row"}`;
if(q.choices){row.innerHTML=`<span class="response-player"></span><div class="player-choice-grid"></div><span class="attempt-counter"></span><span class="response-status"></span>`;row.querySelector(".response-player").textContent=p.name;const grid=row.querySelector(".player-choice-grid"),tried=(saved.history||[]).map(normalizeAnswer);getChoiceOrder(q).forEach(choice=>{const button=document.createElement("button");button.type="button";button.className="player-choice-btn";button.textContent=choice;const alreadyTried=tried.includes(normalizeAnswer(choice));button.disabled=locked||alreadyTried;button.classList.toggle("tried",alreadyTried&&!saved.correct);button.classList.toggle("selected-correct",Boolean(saved.correct&&normalizeAnswer(saved.value)===normalizeAnswer(choice)));button.onclick=()=>submitPlayerAnswer(i,choice);grid.append(button)});
}else{row.innerHTML=`<span class="response-player"></span><input class="response-input" maxlength="80" autocomplete="off" placeholder="Réponse de ${p.name}" ${locked?"disabled":""}><button class="validate-answer" ${locked?"disabled":""}>Valider</button><span class="attempt-counter"></span><span class="response-status"></span>`;row.querySelector(".response-player").textContent=p.name;const input=row.querySelector(".response-input"),button=row.querySelector(".validate-answer");input.value=saved.correct?saved.value||"":"";const submit=()=>submitPlayerAnswer(i,input.value);button.onclick=submit;input.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();submit()}})}
const counter=row.querySelector(".attempt-counter"),status=row.querySelector(".response-status");counter.textContent=`Essais : ${Math.min(attempts,MAX_ATTEMPTS)}/${MAX_ATTEMPTS}`;if(saved.correct)status.textContent=`Bonne réponse · +${saved.points} pts`;else if(attempts>=MAX_ATTEMPTS)status.textContent="3 essais utilisés · réponse bloquée";else if(state.revealed)status.textContent=attempts?`Réponse révélée après ${attempts} essai${attempts>1?"s":""}`:"Réponse non validée";else if(attempts)status.textContent=`Réponse incorrecte · ${MAX_ATTEMPTS-attempts} essai${MAX_ATTEMPTS-attempts>1?"s":""} restant${MAX_ATTEMPTS-attempts>1?"s":""}`;else status.textContent="3 essais disponibles";box.append(row)});updateResponseProgress()}
function updateResponseProgress(){const responses=responsesForQuestion(),count=state.players.filter((_,i)=>{const r=normalizeSavedResponse(responses[i]||{});return Boolean(r.correct||r.locked||(r.attempts||0)>=MAX_ATTEMPTS)}).length;$("#responseProgress").textContent=`${count}/${state.players.length} joueur${state.players.length>1?"s":""} verrouillé${count>1?"s":""}`}
function submitPlayerAnswer(playerIndex,value){if(state.revealed||!value.trim())return;const responses=responsesForQuestion(),saved=normalizeSavedResponse(responses[playerIndex]||{}),attempts=saved.attempts||0;if(saved.correct||saved.locked||attempts>=MAX_ATTEMPTS)return;const q=current(),correct=isCorrectAnswer(value,q),newAttempts=attempts+1,points=correct?getAvailablePoints(q):0;responses[playerIndex]={...saved,value:value.trim(),attempts:newAttempts,submitted:correct||newAttempts>=MAX_ATTEMPTS,locked:correct||newAttempts>=MAX_ATTEMPTS,correct,points,history:[...(saved.history||[]),value.trim()]};if(correct){state.players[playerIndex].score+=points;beep(820,.14)}else beep(210,.18);renderScores();renderResponseInputs();save()}
function undoAutoPointsForQuestion(){const responses=responsesForQuestion();Object.entries(responses).forEach(([i,r])=>{if(r.correct&&r.points&&!r.manualRemoved){state.players[Number(i)].score-=r.points;r.manualRemoved=true}})}
function renderQuestion(){clearTimer();state.revealed=false;state.clues=0;const r=state.activeRounds[state.round],q=current();$("#roundKicker").textContent=`MANCHE ${state.round+1} · QUESTION ${state.question+1}/${r.questions.length}`;$("#roundTitle").textContent=r.title;$("#roundRules").textContent=r.rules;$("#questionText").textContent=q.q;$("#difficulty").textContent="★".repeat(q.difficulty)+"☆".repeat(5-q.difficulty);$("#answerPanel").classList.add("hidden");$("#awardPanel").classList.add("hidden");$("#clueArea").innerHTML="";$("#choices").innerHTML="";$("#visualArea").className="visual-area hidden";$("#visualArea").innerHTML="";
if(q.choices){$("#choices").innerHTML=`<p class="qcm-instruction">Choisis directement une réponse sur la ligne de ton joueur.</p>`}
if(q.image){const v=$("#visualArea");v.classList.remove("hidden");v.classList.add(q.imageMode||"");v.innerHTML=`<img src="${q.image}" alt="Sprite mystère" onerror="this.alt='Sprite indisponible hors connexion';this.style.display='none'">`}
$("#clueBtn").disabled=!q.clues;$("#clueBtn").textContent=q.clues?"Afficher un indice":"Pas d’indice";$("#revealBtn").disabled=false;$("#prevBtn").disabled=state.round===0&&state.question===0;$("#nextBtn").textContent=(state.round===state.activeRounds.length-1&&state.question===r.questions.length-1)?"Voir le podium →":"Suivant →";renderResponseInputs();startTimer();renderRoundList();}
function startTimer(){const sec=state.settings.timer;const box=$("#timerBox");if(!sec){box.classList.add("hidden");return}box.classList.remove("hidden");state.timeLeft=sec;updateTimer();state.timer=setInterval(()=>{state.timeLeft--;updateTimer();if(state.timeLeft<=0){clearTimer();beep(180,.35);reveal()}},1000)}
function updateTimer(){const box=$("#timerBox");$("#timerValue").textContent=state.timeLeft;box.classList.toggle("warning",state.timeLeft<=10&&state.timeLeft>5);box.classList.toggle("danger",state.timeLeft<=5)}
function clearTimer(){if(state.timer){clearInterval(state.timer);state.timer=null}}
function showClue(){const q=current();if(!q.clues||state.clues>=q.clues.length)return;const clue=document.createElement("div");clue.className="clue";clue.textContent=`Indice ${state.clues+1} · ${q.clues[state.clues]}`;$("#clueArea").append(clue);state.clues++;if(q.image&&state.clues>=1){$("#visualArea").classList.remove("silhouette","pixelated")}if(state.clues>=q.clues.length)$("#clueBtn").disabled=true;beep(620)}
function getAvailablePoints(q){if(Array.isArray(q.points))return q.points[Math.min(state.clues,q.points.length-1)]||q.points.at(-1);return q.points||10}
function reveal(){if(state.revealed)return;state.revealed=true;clearTimer();const q=current(),responses=responsesForQuestion();$("#answerText").textContent=q.a;$("#explanationText").textContent=q.exp;$("#sourceText").textContent=q.source+(q.warning?" ⚠ Fiche signalée pour révision dans la banque de questions.":"");$("#answerPanel").classList.remove("hidden");$("#awardPanel").classList.remove("hidden");$("#revealBtn").disabled=true;const pts=getAvailablePoints(q);$("#pointsHint").textContent=`Valeur actuelle : ${pts} point${pts>1?"s":""}. Les bonnes réponses saisies ont déjà été créditées.`;const aw=$("#awardButtons");aw.innerHTML="";state.players.forEach((p,i)=>{const auto=responses[i]?.correct&&!responses[i]?.manualRemoved;const b=document.createElement("button");b.className="award-player"+(auto?" awarded":"");b.textContent=`${p.name} ${auto?"✓":"+"}${pts}`;b.onclick=()=>{const r=responses[i];if(b.classList.contains("awarded")){p.score-=pts;b.classList.remove("awarded");b.textContent=`${p.name} +${pts}`;if(r)r.manualRemoved=true}else{p.score+=pts;b.classList.add("awarded");b.textContent=`${p.name} ✓${pts}`;if(r)r.manualRemoved=false;beep(820)}renderScores();save()};aw.append(b)});renderResponseInputs();beep(760,.16)}
function next(){const r=state.activeRounds[state.round];if(state.question<r.questions.length-1)state.question++;else if(state.round<state.activeRounds.length-1){state.round++;state.question=0}else{return finish()};renderQuestion();save()}
function prev(){if(state.question>0)state.question--;else if(state.round>0){state.round--;state.question=state.activeRounds[state.round].questions.length-1}else return;renderQuestion();save()}
function finish(){clearTimer();showScreen("final");const sorted=[...state.players].sort((a,b)=>b.score-a.score);const medals=["🥇","🥈","🥉"];const order=sorted.slice(0,3);const display=order.length===1?order:[order[1],order[0],order[2]].filter(Boolean);$("#podium").innerHTML=display.map(p=>{const rank=sorted.indexOf(p);return `<div class="podium-place ${rank===0?'first':rank===1?'second':'third'}"><div class="medal">${medals[rank]}</div><h3>${p.name}</h3><strong>${p.score} pts</strong></div>`}).join("");$("#finalRanking").innerHTML=sorted.map((p,i)=>`<div class="final-row"><span>${i+1}. ${p.name}</span><strong>${p.score} points</strong></div>`).join("");localStorage.removeItem("gqpu-state")}
function save(){localStorage.setItem("gqpu-state",JSON.stringify({players:state.players,round:state.round,question:state.question,responses:state.responses,settings:state.settings,activeRounds:state.activeRounds,choiceOrders:state.choiceOrders}))}
$("#clueBtn").onclick=showClue;$("#revealBtn").onclick=reveal;$("#nextBtn").onclick=next;$("#prevBtn").onclick=prev;$("#fullscreenBtn").onclick=()=>document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen();$("#resetBtn").onclick=()=>{if(confirm("Réinitialiser et tirer de nouvelles questions ?")){localStorage.removeItem("gqpu-state");location.reload()}};$("#replayBtn").onclick=()=>{localStorage.removeItem("gqpu-state");location.reload()};
