# Grand Quiz Pokémon Ultimate — V2.5

## Nouveauté principale

- Pour les questions à choix multiples, chaque joueur répond en cliquant directement sur l’un des quatre boutons de sa ligne.
- Chaque clic consomme un essai en cas de mauvaise réponse.
- Une proposition déjà tentée devient indisponible, afin de ne pas gaspiller deux fois un essai sur le même choix.
- Après trois erreurs, tous les boutons du joueur sont bloqués.
- Pour les questions ouvertes, le champ texte et le bouton Valider sont conservés.
- L’ordre des propositions reste stable pendant toute la question, même après une mauvaise réponse.

Décompressez l’archive puis ouvrez `index.html`.
